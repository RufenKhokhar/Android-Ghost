package me.vickychijwani.spectre.util.functions;

/**
 * A zero-argument action.
 */
public interface Action0 {

    void call();

}
