package me.vickychijwani.spectre.event;

public class ForceCancelRefreshEvent {

}
