package me.vickychijwani.spectre.event;

public class CreatePostEvent {

    public CreatePostEvent() {}

}
