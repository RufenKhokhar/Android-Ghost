package me.vickychijwani.spectre.event;

public class LoginDoneEvent {

    public final String blogUrl;

    public LoginDoneEvent(String blogUrl) {
        this.blogUrl = blogUrl;
    }

}
