package me.vickychijwani.spectre.auth;

public final class PasswordAuth {

    public static class Params {

        public final String blogUrl;

        public Params(String blogUrl) {
            this.blogUrl = blogUrl;
        }

    }

}
