package me.vickychijwani.spectre.network;

public interface ApiProviderFactory {

    ApiProvider create(String blogUrl);

}
