package me.vickychijwani.spectre.util.functions;

/**
 * A one-argument action.
 */
public interface Action1<T> {

    void call(T t);

}
