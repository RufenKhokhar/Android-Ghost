package me.vickychijwani.spectre.model;

public abstract class DBConfiguration {

    public static final int METADATA_DB_SCHEMA_VERSION = 4;

    public static final int DATA_DB_SCHEMA_VERSION = 4;

}
