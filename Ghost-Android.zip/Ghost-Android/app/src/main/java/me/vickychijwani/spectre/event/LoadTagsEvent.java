package me.vickychijwani.spectre.event;

public class LoadTagsEvent {

}
