var _ = require('lodash-node');

module.exports = {};

module.exports.schema = {
    access_token: String,
    expires_in: Number,
    token_type: 'Bearer',
};
