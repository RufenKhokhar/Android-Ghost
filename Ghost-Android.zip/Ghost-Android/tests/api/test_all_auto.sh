#!/usr/bin/env sh
jasmine-node . --growl --autotest --watch . --color
